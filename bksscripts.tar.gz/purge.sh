#!/bin/bash

. /env.sh

#"${MC_SSH}" "${MC_USER}"@"${MC_SRVIP}" -p "${MC_SSHPORT}" "${oscmd1}"
#"${MC_SSH}" "${MC_USER}"@"${MC_SRVIP}" -p "${MC_SSHPORT}"
#screen -p 0 -S mcs -X eval 'stuff "save-all"\015'
#"${MC_RCON}" -H "${MC_SRVIP}" -P "${MC_RCONPORT}" -p "${MC_RCONPASS}"
#"${MC_RCON}" -H "${MC_SRVIP}" -P "${MC_RCONPORT}" -p "${MC_RCONPASS}" -s "${rccmd1}"

rccmd0='say データベースのパージを実施します。長時間動作が重くなる場合があります。'
PURGEDAY='30'

${MC_RCON} -H "${MC_SRVIP}" -P "${MC_RCONPORT}" -p "${MC_RCONPASS}" -s "${rccmd0}"
sleep 10
${MC_RCON} -H "${MC_SRVIP}" -P "${MC_RCONPORT}" -p "${MC_RCONPASS}" -s "co purge t:""${PURGEDAY}""d"

