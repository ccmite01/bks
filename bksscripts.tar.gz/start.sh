#!/bin/bash

. /env.sh

#"${MC_SSH}" "${MC_USER}"@"${MC_SRVIP}" -p "${MC_SSHPORT}"
#screen -p 0 -S mcs -X eval 'stuff "save-all"\015'
#"${MC_RCON}" -H "${MC_SRVIP}" -P "${MC_RCONPORT}" -p "${MC_RCONPASS}"

#"${MC_SSH}" "${MC_USER}"@"${MC_SRVIP}" -p "${MC_SSHPORT}" "${sshcmd0}"
#"${MC_RCON}" -H "${MC_SRVIP}" -P "${MC_RCONPORT}" -p "${MC_RCONPASS}" -s "${rccmd0}"

cd /opt/docker-compose/${MC_INSTANCE_NAME}; /usr/local/bin/docker-compose up -d
